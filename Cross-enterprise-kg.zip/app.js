// Enterprise Data
const enterpriseData = {
  assets: [
    {id: "AST-001", name: "CNC Machine Unit 3", type: "Manufacturing Equipment", location: "Pune", status: "Active", risk_score: 25, utilization: 87, assigned_to: "ENG-001", value_inr: "45000000", last_maintenance: "2025-11-15"},
    {id: "AST-002", name: "ERP Server Primary", type: "IT Infrastructure", location: "Mumbai Data Center", status: "Active", risk_score: 12, health: 95, assigned_to: "ENG-003", value_inr: "12000000", uptime: 99.8},
    {id: "AST-003", name: "Warehouse RFID System", type: "Warehouse System", location: "Chennai", status: "Active", risk_score: 35, active_locations: 3, assigned_to: "LOG-002", value_inr: "8500000"},
    {id: "AST-004", name: "Backup Power Generator", type: "Infrastructure", location: "Bangalore", status: "Active", risk_score: 45, fuel_level: 78, assigned_to: "ENG-002", value_inr: "5200000"},
    {id: "VEH-001", name: "Fleet Vehicle Alpha", type: "Transport", location: "Bangalore", status: "Active", risk_score: 28, fuel_efficiency: 92, assigned_to: "LOG-001", value_inr: "1200000"}
  ],
  contracts: [
    {id: "CON-001", name: "Supplier Agreement - Steel", vendor: "Bangalore Steels Ltd", start_date: "2024-01-15", end_date: "2026-01-14", value_inr: "4500000", status: "Active", risk_score: 18, on_time_delivery: 94, compliance: "Pass", assigned_to: "PROC-001"},
    {id: "CON-002", name: "IT Services Contract", vendor: "Infosys Limited", start_date: "2023-06-01", end_date: "2025-05-31", value_inr: "12000000", status: "Active", risk_score: 8, sla_compliance: 99.2, compliance: "Pass", assigned_to: "PROC-002"},
    {id: "CON-003", name: "Office Space Lease", vendor: "Real Estate Partners", start_date: "2024-06-01", end_date: "2025-12-31", value_inr: "2500000", status: "Expiring Soon", risk_score: 52, days_to_expiry: 60, compliance: "At Risk", assigned_to: "PROC-003"},
    {id: "CON-004", name: "Logistics Services", vendor: "Chennai Logistics Corp", start_date: "2024-03-10", end_date: "2025-03-09", value_inr: "3800000", status: "Active", risk_score: 35, delivery_performance: 87, compliance: "Pass", assigned_to: "LOG-001"}
  ],
  personnel: [
    {id: "ENG-001", name: "Rajesh Kumar", role: "Senior Manufacturing Engineer", department: "Operations", skills: ["CNC Programming", "AutoCAD", "Process Design"], allocation_percent: 85, availability_days: 1, risk_score: 22, performance_rating: 4.7, location: "Pune"},
    {id: "ENG-002", name: "Priya Sharma", role: "Infrastructure Engineer", department: "IT", skills: ["System Administration", "Cloud Services", "Network Design"], allocation_percent: 78, availability_days: 3, risk_score: 18, performance_rating: 4.5, location: "Mumbai"},
    {id: "ENG-003", name: "Amit Patel", role: "Senior Systems Engineer", department: "IT", skills: ["Database Management", "ERP Systems", "Security"], allocation_percent: 92, availability_days: 0, risk_score: 28, performance_rating: 4.6, location: "Mumbai"},
    {id: "LOG-001", name: "Suresh Naidu", role: "Logistics Manager", department: "Supply Chain", skills: ["Supply Chain Management", "Fleet Operations", "Vendor Management"], allocation_percent: 88, availability_days: 1, risk_score: 25, performance_rating: 4.4, location: "Bangalore"},
    {id: "LOG-002", name: "Neha Rao", role: "Warehouse Supervisor", department: "Supply Chain", skills: ["Warehouse Management", "Inventory Control", "Quality Assurance"], allocation_percent: 82, availability_days: 2, risk_score: 32, performance_rating: 4.3, location: "Chennai"},
    {id: "PROC-001", name: "Vikram Desai", role: "Procurement Specialist", department: "Procurement", skills: ["Supplier Management", "Contract Negotiation", "Cost Analysis"], allocation_percent: 78, availability_days: 4, risk_score: 15, performance_rating: 4.8, location: "Pune"},
    {id: "PROC-002", name: "Anjali Verma", role: "Procurement Officer", department: "Procurement", skills: ["Vendor Evaluation", "RFQ Management", "Compliance"], allocation_percent: 81, availability_days: 2, risk_score: 20, performance_rating: 4.5, location: "Mumbai"},
    {id: "PROC-003", name: "Ramesh Kumar", role: "Contract Manager", department: "Procurement", skills: ["Contract Management", "Risk Assessment", "Negotiation"], allocation_percent: 95, availability_days: 0, risk_score: 38, performance_rating: 4.2, location: "Bangalore"}
  ],
  suppliers: [
    {id: "SUP-001", name: "Bangalore Steels Ltd", location: "Bangalore, Karnataka", category: "Raw Materials", reliability_score: 94, on_time_rate: 94, quality_score: 92, risk_score: 12, active_contracts: 2, total_transaction_value: 8900000},
    {id: "SUP-002", name: "Chennai Electronics", location: "Chennai, Tamil Nadu", category: "Components", reliability_score: 87, on_time_rate: 83, quality_score: 88, risk_score: 28, active_contracts: 1, total_transaction_value: 3200000},
    {id: "SUP-003", name: "Kolkata Components", location: "Kolkata, West Bengal", category: "Components", reliability_score: 89, on_time_rate: 89, quality_score: 85, risk_score: 22, active_contracts: 2, total_transaction_value: 5400000},
    {id: "SUP-004", name: "Bangalore Logistics Ltd", location: "Bangalore, Karnataka", category: "Services", reliability_score: 91, on_time_rate: 92, quality_score: 90, risk_score: 18, active_contracts: 1, total_transaction_value: 3800000},
    {id: "SUP-005", name: "Mumbai Chemicals", location: "Mumbai, Maharashtra", category: "Raw Materials", reliability_score: 85, on_time_rate: 81, quality_score: 83, risk_score: 35, active_contracts: 1, total_transaction_value: 2100000}
  ],
  relationships: [
    {source: "AST-001", target: "ENG-001", type: "assigned_to"},
    {source: "AST-002", target: "ENG-003", type: "managed_by"},
    {source: "CON-001", target: "SUP-001", type: "references"},
    {source: "CON-001", target: "PROC-001", type: "assigned_to"},
    {source: "ENG-001", target: "AST-001", type: "operates"},
    {source: "LOG-001", target: "VEH-001", type: "manages"},
    {source: "SUP-001", target: "CON-001", type: "fulfills"},
    {source: "ENG-002", target: "AST-004", type: "maintains"},
    {source: "LOG-002", target: "AST-003", type: "supervises"},
    {source: "CON-004", target: "SUP-004", type: "contracts"},
    {source: "PROC-003", target: "CON-003", type: "manages"},
    {source: "ENG-003", target: "PROC-002", type: "coordinates_with"},
    {source: "SUP-001", target: "SUP-003", type: "tier2_relationship"}
  ]
};

// State Management
let state = {
  currentTab: 'graph',
  selectedEntity: null,
  filterType: 'all',
  filterTime: '30d',
  visibleEntityTypes: {assets: true, contracts: true, personnel: true, suppliers: true},
  lastUpdate: new Date()
};

let charts = {};

// Utility Functions
function formatCurrency(value) {
  const numValue = parseInt(value);
  if (numValue >= 10000000) return `₹${(numValue / 10000000).toFixed(2)}Cr`;
  if (numValue >= 100000) return `₹${(numValue / 100000).toFixed(2)}L`;
  return `₹${(numValue / 1000).toFixed(0)}K`;
}

function getRiskLevel(score) {
  if (score < 25) return 'low';
  if (score < 50) return 'medium';
  return 'high';
}

function getStatusClass(status) {
  if (status === 'Active') return 'active';
  if (status === 'Expiring Soon') return 'expiring';
  return 'critical';
}

function getAllEntities() {
  return [
    ...enterpriseData.assets.map(e => ({...e, entityType: 'asset'})),
    ...enterpriseData.contracts.map(e => ({...e, entityType: 'contract'})),
    ...enterpriseData.personnel.map(e => ({...e, entityType: 'personnel'})),
    ...enterpriseData.suppliers.map(e => ({...e, entityType: 'supplier'}))
  ];
}

function getEntityById(id) {
  const allEntities = getAllEntities();
  return allEntities.find(e => e.id === id);
}

// Toast Notification
function showToast(message, type = 'info') {
  const container = document.querySelector('.toast-container') || createToastContainer();
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  
  setTimeout(() => {
    toast.remove();
  }, 4000);
}

function createToastContainer() {
  const container = document.createElement('div');
  container.className = 'toast-container';
  document.body.appendChild(container);
  return container;
}

// Render Functions
function renderApp() {
  const root = document.getElementById('app-root');
  root.innerHTML = `
    ${renderTopNav()}
    <div class="main-layout">
      ${renderLeftSidebar()}
      <div class="content-area">
        ${renderTabs()}
        ${renderTabContent()}
      </div>
      <div class="right-sidebar" id="right-sidebar">
        ${state.selectedEntity ? renderEntityDetails() : ''}
      </div>
    </div>
  `;
  
  attachEventListeners();
  if (state.currentTab === 'graph') renderGraph();
  if (state.currentTab === 'decision') renderCharts();
}

function renderTopNav() {
  const now = new Date();
  const timeString = now.toLocaleTimeString('en-IN', {hour: '2-digit', minute: '2-digit', second: '2-digit'});
  
  return `
    <nav class="top-nav">
      <div class="nav-brand">
        <h1>Cross-Enterprise Intelligence Hub</h1>
      </div>
      <div class="nav-controls">
        <div class="live-indicator">
          <span class="pulse-dot"></span>
          <span>Live • Updating every 5 seconds</span>
        </div>
        <div class="time-display">${timeString}</div>
        <div class="filter-group">
          <label>Time Range:</label>
          <select id="time-filter" value="${state.filterTime}">
            <option value="7d">Last 7 Days</option>
            <option value="30d" selected>Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
          </select>
        </div>
        <div class="filter-group">
          <label>Entity Type:</label>
          <select id="type-filter" value="${state.filterType}">
            <option value="all" selected>All Types</option>
            <option value="assets">Assets Only</option>
            <option value="contracts">Contracts Only</option>
            <option value="personnel">Personnel Only</option>
            <option value="suppliers">Suppliers Only</option>
          </select>
        </div>
      </div>
    </nav>
  `;
}

function renderLeftSidebar() {
  const totalAssets = enterpriseData.assets.length;
  const activeContracts = enterpriseData.contracts.filter(c => c.status === 'Active').length;
  const totalPersonnel = enterpriseData.personnel.length;
  const supplyChainNodes = enterpriseData.suppliers.length;
  
  const avgRisk = Math.round(
    [...enterpriseData.assets, ...enterpriseData.contracts, ...enterpriseData.personnel, ...enterpriseData.suppliers]
      .reduce((sum, e) => sum + e.risk_score, 0) / 
    (totalAssets + enterpriseData.contracts.length + totalPersonnel + supplyChainNodes)
  );
  
  return `
    <aside class="left-sidebar">
      <div class="sidebar-section">
        <h3>Quick Stats</h3>
        <div class="stat-card">
          <div class="stat-card-label">Total Assets</div>
          <div class="stat-card-value">${totalAssets}</div>
        </div>
        <div class="stat-card">
          <div class="stat-card-label">Active Contracts</div>
          <div class="stat-card-value">${activeContracts}</div>
        </div>
        <div class="stat-card">
          <div class="stat-card-label">Personnel Count</div>
          <div class="stat-card-value">${totalPersonnel}</div>
        </div>
        <div class="stat-card">
          <div class="stat-card-label">Supply Chain Nodes</div>
          <div class="stat-card-value">${supplyChainNodes}</div>
        </div>
      </div>
      
      <div class="sidebar-section">
        <h3>Risk Score</h3>
        <div class="risk-gauge">
          <div class="gauge-value">${avgRisk}</div>
          <div class="gauge-label">Average Risk Score</div>
        </div>
      </div>
      
      <div class="sidebar-section">
        <h3>Decision Alerts</h3>
        <div class="alert-item critical">
          Office lease expiring in 60 days (CON-003)
        </div>
        <div class="alert-item warning">
          Generator fuel level at 78% (AST-004)
        </div>
        <div class="alert-item warning">
          Chennai RFID risk score elevated (AST-003)
        </div>
        <div class="alert-item info">
          3 personnel over 90% allocated
        </div>
        <div class="alert-item info">
          2 suppliers with on-time rate below 85%
        </div>
      </div>
    </aside>
  `;
}

function renderTabs() {
  return `
    <div class="tabs">
      <button class="tab ${state.currentTab === 'graph' ? 'active' : ''}" data-tab="graph">
        Knowledge Graph
      </button>
      <button class="tab ${state.currentTab === 'decision' ? 'active' : ''}" data-tab="decision">
        Decision Intelligence
      </button>
      <button class="tab ${state.currentTab === 'analytics' ? 'active' : ''}" data-tab="analytics">
        Detailed Analytics
      </button>
    </div>
  `;
}

function renderTabContent() {
  return `
    <div id="graph-tab" class="tab-content ${state.currentTab === 'graph' ? 'active' : ''}">
      ${renderGraphTab()}
    </div>
    <div id="decision-tab" class="tab-content ${state.currentTab === 'decision' ? 'active' : ''}">
      ${renderDecisionTab()}
    </div>
    <div id="analytics-tab" class="tab-content ${state.currentTab === 'analytics' ? 'active' : ''}">
      ${renderAnalyticsTab()}
    </div>
  `;
}

function renderGraphTab() {
  return `
    <div class="graph-container">
      <div class="graph-controls">
        <button class="${state.visibleEntityTypes.assets ? 'active' : ''}" data-type="assets">Assets</button>
        <button class="${state.visibleEntityTypes.contracts ? 'active' : ''}" data-type="contracts">Contracts</button>
        <button class="${state.visibleEntityTypes.personnel ? 'active' : ''}" data-type="personnel">Personnel</button>
        <button class="${state.visibleEntityTypes.suppliers ? 'active' : ''}" data-type="suppliers">Suppliers</button>
      </div>
      <div id="graph-canvas"></div>
    </div>
  `;
}

function renderDecisionTab() {
  return `
    <div class="dashboard-grid">
      <div class="widget">
        <h3 class="widget-title">Risk Analysis</h3>
        <div class="risk-item">
          <span class="risk-label">Supply Chain Risk</span>
          <span class="risk-score medium">24</span>
        </div>
        <div class="risk-item">
          <span class="risk-label">Contract Risk</span>
          <span class="risk-score medium">28</span>
        </div>
        <div class="risk-item">
          <span class="risk-label">Asset Risk</span>
          <span class="risk-score medium">29</span>
        </div>
        <div class="risk-item">
          <span class="risk-label">Personnel Risk</span>
          <span class="risk-score low">24</span>
        </div>
      </div>
      
      <div class="widget">
        <h3 class="widget-title">Asset Allocation</h3>
        <div class="chart-container">
          <canvas id="allocation-chart"></canvas>
        </div>
      </div>
      
      <div class="widget">
        <h3 class="widget-title">Contract Performance</h3>
        <div class="kpi-grid">
          <div class="kpi-card">
            <div class="kpi-value">92%</div>
            <div class="kpi-label">On-Time Delivery</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-value">95%</div>
            <div class="kpi-label">Fulfillment Score</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-value">-3%</div>
            <div class="kpi-label">Cost Variance</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-value">3/4</div>
            <div class="kpi-label">Compliance Pass</div>
          </div>
        </div>
      </div>
      
      <div class="widget">
        <h3 class="widget-title">Supply Chain Health</h3>
        <div style="font-size: 12px; color: var(--color-text-secondary);">
          <p style="margin-bottom: 8px;"><strong>Top Risks:</strong></p>
          <p style="margin-bottom: 4px;">• Chennai Electronics - Low on-time rate (83%)</p>
          <p style="margin-bottom: 4px;">• Mumbai Chemicals - Quality concerns</p>
          <p style="margin-bottom: 8px;">• Kolkata Components - Lead time variance</p>
          <p><strong>Recommendation:</strong> Diversify supplier base in Components category</p>
        </div>
      </div>
      
      <div class="widget" style="grid-column: span 2;">
        <h3 class="widget-title">Asset Utilization Trend (30 Days)</h3>
        <div class="chart-container">
          <canvas id="utilization-chart"></canvas>
        </div>
      </div>
    </div>
  `;
}

function renderAnalyticsTab() {
  const entities = getAllEntities();
  const filteredEntities = state.filterType === 'all' ? entities : entities.filter(e => e.entityType === state.filterType.slice(0, -1));
  
  return `
    <div class="analytics-controls">
      <input type="text" id="search-input" placeholder="Search entities..." />
      <select id="entity-type-filter">
        <option value="all">All Entity Types</option>
        <option value="asset">Assets</option>
        <option value="contract">Contracts</option>
        <option value="personnel">Personnel</option>
        <option value="supplier">Suppliers</option>
      </select>
      <button class="btn btn--secondary" onclick="exportData()">Export Data</button>
    </div>
    
    <div class="data-table">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Type</th>
            <th>Location</th>
            <th>Status</th>
            <th>Risk Score</th>
            <th>Details</th>
          </tr>
        </thead>
        <tbody>
          ${filteredEntities.map(entity => `
            <tr>
              <td>${entity.id}</td>
              <td>${entity.name}</td>
              <td>${entity.type || entity.role || entity.category || entity.entityType}</td>
              <td>${entity.location || 'N/A'}</td>
              <td><span class="status-badge ${getStatusClass(entity.status || 'Active')}">${entity.status || 'Active'}</span></td>
              <td><span class="risk-score ${getRiskLevel(entity.risk_score)}">${entity.risk_score}</span></td>
              <td><button class="btn btn--sm" onclick="viewEntity('${entity.id}')">View</button></td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function renderEntityDetails() {
  const entity = getEntityById(state.selectedEntity);
  if (!entity) return '';
  
  const relationships = enterpriseData.relationships.filter(r => 
    r.source === entity.id || r.target === entity.id
  );
  
  return `
    <div class="detail-header">
      <h3>Entity Details</h3>
      <button class="close-btn" onclick="closeDetails()">✕</button>
    </div>
    
    <div class="detail-section">
      <h4>${entity.name}</h4>
      <div class="detail-item">
        <span class="detail-item-label">ID</span>
        <span class="detail-item-value">${entity.id}</span>
      </div>
      <div class="detail-item">
        <span class="detail-item-label">Type</span>
        <span class="detail-item-value">${entity.entityType}</span>
      </div>
      <div class="detail-item">
        <span class="detail-item-label">Risk Score</span>
        <span class="detail-item-value risk-score ${getRiskLevel(entity.risk_score)}">${entity.risk_score}</span>
      </div>
      ${entity.location ? `
        <div class="detail-item">
          <span class="detail-item-label">Location</span>
          <span class="detail-item-value">${entity.location}</span>
        </div>
      ` : ''}
    </div>
    
    <div class="detail-section">
      <h4>Key Metrics</h4>
      ${Object.entries(entity)
        .filter(([key, val]) => !['id', 'name', 'entityType', 'location', 'risk_score'].includes(key))
        .slice(0, 6)
        .map(([key, val]) => `
          <div class="detail-item">
            <span class="detail-item-label">${key.replace(/_/g, ' ')}</span>
            <span class="detail-item-value">${Array.isArray(val) ? val.join(', ') : val}</span>
          </div>
        `).join('')}
    </div>
    
    <div class="detail-section">
      <h4>Relationships (${relationships.length})</h4>
      ${relationships.map(rel => {
        const relatedId = rel.source === entity.id ? rel.target : rel.source;
        const relatedEntity = getEntityById(relatedId);
        return `<span class="relationship-chip" onclick="viewEntity('${relatedId}')">${rel.type} → ${relatedEntity?.name || relatedId}</span>`;
      }).join('')}
    </div>
  `;
}

// Graph Rendering (Simplified SVG-based)
function renderGraph() {
  const canvas = document.getElementById('graph-canvas');
  if (!canvas) return;
  
  const allEntities = getAllEntities();
  const filteredEntities = allEntities.filter(e => state.visibleEntityTypes[e.entityType + 's']);
  
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;
  
  // Simple force-directed layout simulation
  const nodes = filteredEntities.map((e, i) => ({
    ...e,
    x: Math.random() * (width - 100) + 50,
    y: Math.random() * (height - 100) + 50,
    radius: 20
  }));
  
  const links = enterpriseData.relationships.filter(rel => {
    const sourceExists = nodes.find(n => n.id === rel.source);
    const targetExists = nodes.find(n => n.id === rel.target);
    return sourceExists && targetExists;
  });
  
  // Create SVG
  canvas.innerHTML = `
    <svg width="${width}" height="${height}" style="background: var(--color-surface);">
      ${links.map(link => {
        const source = nodes.find(n => n.id === link.source);
        const target = nodes.find(n => n.id === link.target);
        if (!source || !target) return '';
        return `<line x1="${source.x}" y1="${source.y}" x2="${target.x}" y2="${target.y}" stroke="var(--color-border)" stroke-width="2" opacity="0.4" />`;
      }).join('')}
      ${nodes.map(node => {
        const colors = {
          asset: '#a855f7',
          contract: '#f59e0b',
          personnel: '#3b82f6',
          supplier: '#10b981'
        };
        return `
          <circle 
            cx="${node.x}" 
            cy="${node.y}" 
            r="${node.radius}" 
            fill="${colors[node.entityType]}" 
            stroke="var(--color-surface)" 
            stroke-width="3" 
            style="cursor: pointer;" 
            data-id="${node.id}"
            class="graph-node"
          />
          <text 
            x="${node.x}" 
            y="${node.y + node.radius + 15}" 
            text-anchor="middle" 
            fill="var(--color-text-secondary)" 
            font-size="10"
            style="pointer-events: none;"
          >${node.id}</text>
        `;
      }).join('')}
    </svg>
  `;
  
  // Add click handlers to nodes
  document.querySelectorAll('.graph-node').forEach(node => {
    node.addEventListener('click', (e) => {
      const id = e.target.getAttribute('data-id');
      viewEntity(id);
    });
  });
}

// Chart Rendering
function renderCharts() {
  setTimeout(() => {
    renderAllocationChart();
    renderUtilizationChart();
  }, 100);
}

function renderAllocationChart() {
  const ctx = document.getElementById('allocation-chart');
  if (!ctx) return;
  
  if (charts.allocation) charts.allocation.destroy();
  
  const avgAllocation = enterpriseData.personnel.reduce((sum, p) => sum + p.allocation_percent, 0) / enterpriseData.personnel.length;
  
  charts.allocation = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Available', 'Assigned', 'Over-allocated'],
      datasets: [{
        label: 'Percentage',
        data: [100 - avgAllocation, avgAllocation - 15, 15],
        backgroundColor: ['#10b981', '#3b82f6', '#ef4444']
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: { beginAtZero: true, max: 100 }
      }
    }
  });
}

function renderUtilizationChart() {
  const ctx = document.getElementById('utilization-chart');
  if (!ctx) return;
  
  if (charts.utilization) charts.utilization.destroy();
  
  const days = Array.from({length: 30}, (_, i) => `Day ${i + 1}`);
  const data1 = Array.from({length: 30}, () => 75 + Math.random() * 20);
  const data2 = Array.from({length: 30}, () => 80 + Math.random() * 15);
  const data3 = Array.from({length: 30}, () => 70 + Math.random() * 25);
  
  charts.utilization = new Chart(ctx, {
    type: 'line',
    data: {
      labels: days,
      datasets: [
        { label: 'Manufacturing', data: data1, borderColor: '#a855f7', backgroundColor: 'rgba(168, 85, 247, 0.1)', tension: 0.4 },
        { label: 'IT Infrastructure', data: data2, borderColor: '#3b82f6', backgroundColor: 'rgba(59, 130, 246, 0.1)', tension: 0.4 },
        { label: 'Logistics', data: data3, borderColor: '#10b981', backgroundColor: 'rgba(16, 185, 129, 0.1)', tension: 0.4 }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'top' }
      },
      scales: {
        y: { beginAtZero: true, max: 100 }
      }
    }
  });
}

// Event Handlers
function attachEventListeners() {
  // Tab switching
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', (e) => {
      state.currentTab = e.target.getAttribute('data-tab');
      renderApp();
    });
  });
  
  // Graph controls
  document.querySelectorAll('.graph-controls button[data-type]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const type = e.target.getAttribute('data-type');
      state.visibleEntityTypes[type] = !state.visibleEntityTypes[type];
      renderApp();
    });
  });
  
  // Filters
  const timeFilter = document.getElementById('time-filter');
  if (timeFilter) {
    timeFilter.addEventListener('change', (e) => {
      state.filterTime = e.target.value;
      showToast(`Time range updated to ${e.target.value}`, 'info');
    });
  }
  
  const typeFilter = document.getElementById('type-filter');
  if (typeFilter) {
    typeFilter.addEventListener('change', (e) => {
      state.filterType = e.target.value;
      renderApp();
    });
  }
  
  // Analytics search
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      // Filter table rows based on search
      const searchTerm = e.target.value.toLowerCase();
      document.querySelectorAll('.data-table tbody tr').forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
      });
    });
  }
  
  const entityTypeFilter = document.getElementById('entity-type-filter');
  if (entityTypeFilter) {
    entityTypeFilter.addEventListener('change', (e) => {
      state.filterType = e.target.value === 'all' ? 'all' : e.target.value + 's';
      renderApp();
    });
  }
}

// Global Functions (accessible from HTML)
window.viewEntity = function(id) {
  state.selectedEntity = id;
  const sidebar = document.getElementById('right-sidebar');
  sidebar.classList.add('open');
  sidebar.innerHTML = renderEntityDetails();
  
  const entity = getEntityById(id);
  showToast(`Viewing details for ${entity?.name}`, 'info');
};

window.closeDetails = function() {
  state.selectedEntity = null;
  const sidebar = document.getElementById('right-sidebar');
  sidebar.classList.remove('open');
  sidebar.innerHTML = '';
};

window.exportData = function() {
  const entities = getAllEntities();
  const dataStr = JSON.stringify(entities, null, 2);
  const dataBlob = new Blob([dataStr], {type: 'application/json'});
  const url = URL.createObjectURL(dataBlob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'enterprise-data.json';
  link.click();
  showToast('Data exported successfully', 'info');
};

// Real-time Updates
function simulateRealTimeUpdates() {
  // Randomly update utilization values
  enterpriseData.assets.forEach(asset => {
    if (asset.utilization) {
      asset.utilization = Math.max(70, Math.min(100, asset.utilization + (Math.random() - 0.5) * 4));
    }
  });
  
  // Update risk scores slightly
  const allEntities = getAllEntities();
  const randomEntity = allEntities[Math.floor(Math.random() * allEntities.length)];
  if (randomEntity) {
    const oldRisk = randomEntity.risk_score;
    randomEntity.risk_score = Math.max(5, Math.min(95, randomEntity.risk_score + (Math.random() - 0.5) * 5));
    
    // Show toast for significant changes
    if (Math.abs(randomEntity.risk_score - oldRisk) > 3) {
      showToast(`Risk score updated for ${randomEntity.name}: ${Math.round(randomEntity.risk_score)}`, 
                randomEntity.risk_score > 50 ? 'critical' : 'info');
    }
  }
  
  state.lastUpdate = new Date();
  
  // Re-render if on decision tab
  if (state.currentTab === 'decision') {
    renderCharts();
  }
  
  // Update time display
  const timeDisplay = document.querySelector('.time-display');
  if (timeDisplay) {
    const now = new Date();
    timeDisplay.textContent = now.toLocaleTimeString('en-IN', {hour: '2-digit', minute: '2-digit', second: '2-digit'});
  }
}

// Initialize App
function init() {
  renderApp();
  
  // Start real-time updates
  setInterval(simulateRealTimeUpdates, 5000);
  
  // Update clock every second
  setInterval(() => {
    const timeDisplay = document.querySelector('.time-display');
    if (timeDisplay) {
      const now = new Date();
      timeDisplay.textContent = now.toLocaleTimeString('en-IN', {hour: '2-digit', minute: '2-digit', second: '2-digit'});
    }
  }, 1000);
}

// Start the app when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}